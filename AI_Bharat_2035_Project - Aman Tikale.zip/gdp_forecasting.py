import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

data = pd.read_csv('data/historic_gdp.csv')
X = data[['Year']]
y = data['GDP']
model = LinearRegression().fit(X, y)
future = pd.DataFrame({'Year': list(range(2024, 2036))})
future['GDP'] = model.predict(future[['Year']])
future.to_csv('data/gdp_forecast_2035.csv', index=False)
plt.plot(data['Year'], data['GDP'], label='Historical')
plt.plot(future['Year'], future['GDP'], label='Forecast')
plt.legend()
plt.savefig('outputs/gdp_forecast.png')