# AI-Bharat-2035
A national-scale AI + data strategy for economic and social upliftment.

## Modules:
- GDP Forecasting
- Healthcare AI Access Models
- Education Access Simulation
- Employment Engine

## Getting Started:
Run `gdp_forecasting.py` to see future GDP trends.

## License:
Open Knowledge India (OKI)